

# list comprehensions  - page 1-8 and 1-9
# [                  ]          # square brackets
# [ for i in range(5) ]         # add an iterating expression
# [ 'x'*1  for i in range(5) ]  # provide an expression to add to list
[ 'x'*i  for i in range(5) ] # ['', 'x', 'xx', 'xxx', 'xxxx']

[ i**3 for i in range(5) ]   # [0, 1, 8, 27, 64]

[ i**3 for i in range(5) if i%2 and i>1]   # [27]
[ j[0:2]  for j in [ 'xxx' for i in range(5)]] ['xx', 'xx', 'xx', 'xx', 'xx']


# Dict comprehensions
#{                    }        # curly braces
#{ for i in range(5)  }        # add an iterating expression
# { i:i**2  for i in range(5) }  # provide key:value pairsto add to list
{ i:i**2  for i in range(5) } # {0: 0, 1: 1, 2: 4, 3: 9, 4: 16}

