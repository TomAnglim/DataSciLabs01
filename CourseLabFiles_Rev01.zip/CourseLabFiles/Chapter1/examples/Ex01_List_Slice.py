# Chapter 1 Bluildings Blocks

# Creating a list - page 1-1
ls = []   # an empty list
ls = [1, 2.4, 'hey', {'a':1, 'b':2}]
print(ls)    
ls= list(range(10)) 
print(ls)

#slicing a list - page 1-2
ls[3]	    # 3
ls[0:5]    # [0, 1, 2, 3, 4]
ls[0:5:2]  # [0, 2, 4]
ls[-1]	    # 9
ls[-2]	    # 8

# Adding content - page 1-3 
ls = list(range(3,10,2))  
ls                        # [3, 5, 7, 9]
ls.append(777)            # [3, 5, 7, 9, 777]
ls
ls.extend('abc')          # [3, 5, 7, 9, 777, 'a', 'b', 'c']
ls
index=0
ls.insert(index,'-34')
ls                        # ['-34', 3, 5, 7, 9, 777, 'a', 'b', 'c']

ls.insert(ls.index(777),888)
ls                   # ['-34', '-34', 3, 5, 7, 9, 888, 777, 'a', 'b', 'c']

ls = ls.append(3)
ls

# Removing content
ls = ['dog', 'pony', 'unicorn']
my_little = ls.pop(1)    
my_little              # pony
ls                     # pony is now removed

ls.remove('unicorn')
ls                     # ['dog']

ls.clear()
ls                     # empty list              


