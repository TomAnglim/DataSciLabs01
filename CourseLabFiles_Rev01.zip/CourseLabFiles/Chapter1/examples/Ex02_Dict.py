# Chapter 1 -- Dict Objects

# Creating Dict and adding content - page 1-5 and 1-6
the_dict = {"key":"value", "A":2, "B":3 }
the_dict   #  {'A': 2, 'B': 3, 'key': 'value'}

same_dict = dict(key="value", A=2, B=3 ) 
same_dict  # {'A': 2, 'B': 3, 'key': 'value'}

the_dict == same_dict    # True 

the_dict['C'] = 3
the_dict     # {'A': 2, 'B': 3, 'C': 3, 'key': 'value'}

the_dict.update((('a',100),('b',200)))
the_dict  #{'A': 2, 'B': 3, 'C': 3, 'a': 100, 'b': 200, 'key': 'value'}

# Removing content page 1-6and 1-7
val = the_dict.pop('A')
val        # 2 
the_dict   # {'B': 3, 'C': 3, 'a': 100, 'b': 200, 'key': 'value'}

val = the_dict.popitem()
val        # ('b', 200)
the_dict   # {'B': 3, 'C': 3, 'a': 100, 'key': 'value'}

if 'a' in the_dict:    # Test for membership
    del the_dict['a']
the_dict   # {'B': 3, 'C': 3, key': 'value'}
    
val = the_dict.get('zebra')
val       # None returned but not printed

val = the_dict.get('zebra', 'default_value')
val       # 'default_value'



