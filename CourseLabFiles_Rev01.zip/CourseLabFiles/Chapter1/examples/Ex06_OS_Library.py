
import os
os.system('dir')

# create a relative path
mypath = os.path.join('tools','image_processing','imp.py')
mypath   #'tools\\image_processing\\imp.py'

os.name
# find path seperator
os.path.sep

# construct a fully-specify path
os.path.abspath(mypath) #'C:\\CourseFiles\\Chapter01\\examples\\tools\\image_processing\\imp.py'

# extract a file from a path
os.path.basename(mypath)  # 'imp.py'

# split off the file extension 
os.path.splitext(mypath)  #  ('tools\\image_processing\\imp', '.py')

# navidate the file system
os.getcwd()  # 'C:\\CourseFiles\\Chapter01\\examples'
os.chdir('..\\notebooks')
os.getcwd()  #'C:\\CourseFiles\\Chapter01\\notebooks'

# create file system objects
os.mkdir('junk')
os.chdir('junk')
os.getcwd()  #'C:\\CourseFiles\\Chapter01\\notebooks\\junk'
open('junkfile','w').close()
os.listdir()
os.getpid()
os.getlogin()
os.stat('junkfile')
os.remove('junkfile')
os.chdir('..')
os.rmdir('junk')
os.listdir()


