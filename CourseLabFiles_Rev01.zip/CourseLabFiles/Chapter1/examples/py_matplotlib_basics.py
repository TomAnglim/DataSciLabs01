#py_matplotlib_basics.py

import matplotlib.pyplot as plt

data=[2,8,3,6,1]
xaxis=[1,2,3,4,5]
plt.plot(data, xaxis)
plt.ylabel('my data')
plt.show()


