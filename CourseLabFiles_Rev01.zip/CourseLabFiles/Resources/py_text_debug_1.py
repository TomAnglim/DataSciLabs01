def buggy_code():
	for i in range(1, 3):
		print(1/i)		
		
buggy_code()		