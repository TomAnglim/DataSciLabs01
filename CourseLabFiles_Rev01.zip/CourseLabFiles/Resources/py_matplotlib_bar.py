#py_matplotlib_bar.py
import matplotlib.pyplot as plt
data=[2,8,3,6,1]
xaxis=[1,2,3,4,5]

plt.bar(left=xaxis, height=data)  
plt.show()