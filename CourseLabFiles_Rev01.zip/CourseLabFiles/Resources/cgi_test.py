import cgi
import gitb
cgitb.enable()
cgi.test()