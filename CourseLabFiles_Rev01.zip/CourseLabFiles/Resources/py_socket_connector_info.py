#py_socket_connector_info.py
import socket
ip_address=             'localhost'           #serving locally only
port =                  8000                  #an arbitrary 4-digit port
protocol_family_name=   socket.AF_INET        #olde tyme IPv4 protocol
socket_type=            socket.SOCK_STREAM    #a simple stream